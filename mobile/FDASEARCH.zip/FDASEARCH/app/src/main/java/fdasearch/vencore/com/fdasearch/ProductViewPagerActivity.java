package fdasearch.vencore.com.fdasearch;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import fdasearch.vencore.com.fdasearch.adapters.ProductSlidePagerAdapter;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;
import fdasearch.vencore.com.fdasearch.utils.RequestManager;

public class ProductViewPagerActivity extends FragmentActivity {
    private static float MIN_SCALE = 0.75f;
    SearchCriteria search;
    /**
     * The pager widget, which handles animation and allows swiping horizontally to access previous
     * and next wizard steps.
     */
    private int mShortAnimationDuration;
    private ViewPager mPager;
    private List<Product> productList;
    private int currentitem = 0;
    private DetailOnPageChangeListener listener;


    /**
     * The pager adapter, which provides the pages to the view pager widget.
     */
    private PagerAdapter mPagerAdapter;

    /*
    *
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_screen_slide_activity);

        // Instantiate a ViewPager and a PagerAdapter.
        mPager = (ViewPager) findViewById(R.id.pager);
        mPager.setPageTransformer(true, new DepthPageTransformer());
        Bundle bundle = getIntent().getExtras();


        if (bundle != null && bundle.getString(MainApplication.PRODUCT_LIST) != null) {
            Type listOfProduct = new TypeToken<List<Product>>() {
            }.getType();
            String s = bundle.getString(MainApplication.PRODUCT_LIST);
            productList = MainApplication.gson.fromJson(s, listOfProduct);
        }

        search = MainApplication.mCriteria;
        Log.i(MainApplication.TAG, "!!!!!!!!  search term is " + search.getStartDate() + search.getEndDate() + search.getSearchKey());
        pullKeyResult();
        if (bundle != null && bundle.getInt(MainApplication.POSITION) >= 0)
            currentitem = bundle.getInt(MainApplication.POSITION);


    }

    /*
    *
    */
    public void pullKeyResult() {
        String url = MainApplication.SEARCHURL;
        boolean isProd = false;
        String prd = "";
        // Log.i(MainApplication.TAG, "search  :``" +search.getProductType().toString());
        if (search != null && search.getProductType() != null) {
            for (int i = 0; i < search.getProductType().size(); i++) {
                isProd = true;
                if (i == 0)
                    prd = MainApplication.SEARCHURL_PRODUCT + "=" + search.getProductType().get(i).toLowerCase();
                else
                    prd += "&" + MainApplication.SEARCHURL_PRODUCT + "=" + search.getProductType().get(i).toLowerCase();
            }
        }
        url += prd + "&";

        if (search != null && search.getSearchKey() != null) {
            if (isProd) {
                url += prd + "&";

            }
            url += MainApplication.KEY_TERM
                    + "=" + search.getSearchKey();
            isProd = true;

        }
        if (search != null && search.getStartDate() != null && search.getStartDate().length() > 0 && search.getEndDate() != null) {
            if (isProd) url += "&";
            url += MainApplication.DATE_RANGE + "=["
                    + search.getStartDate()
                    + "+TO+"
                    + search.getEndDate()
                    + "]";

        }

        Log.i(MainApplication.TAG, "url: " + url);
        JsonObjectRequest jsObjRequest =
                new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            if (response.getString("results") != null) {
                                JSONArray data = (JSONArray) response.get("results");
                                Type listType = new TypeToken<ArrayList<Product>>() {
                                }.getType();
                                List<Product> res = MainApplication.gson.fromJson(data.toString(), listType);
                                productList = new ArrayList<Product>();
                                productList.addAll(res);
                                listener = new DetailOnPageChangeListener();
                                mPagerAdapter = new ProductSlidePagerAdapter(getSupportFragmentManager(), productList);
                                mPager.setAdapter(mPagerAdapter);
                                mPager.setOnPageChangeListener(listener);
                                mPager.setCurrentItem(currentitem);
                                mShortAnimationDuration = getResources().getInteger(android.R.integer.config_shortAnimTime);


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(MainApplication.TAG, "GET URL  : volley error" + error.toString());
                    }
                }
                );
        RequestManager.getRequestQueue().add(jsObjRequest);
    }

    /*
    *
    */
    @Override
    protected void onResume() {
        super.onResume();

    }

    /*
    *
    */
    @Override
    protected void onPause() {
        super.onPause();
    }

    /*
    *
    */
    @Override
    public void onDestroy() {
        super.onDestroy();

        // Remove all content from the FragmentStatePagerAdapter instance.
        mPagerAdapter = new ProductSlidePagerAdapter(getSupportFragmentManager(), null); // Content here may be an ArrayList in Java or a List in C#.
        mPagerAdapter.notifyDataSetChanged();


    }

    /*
    *
    */
    public class DetailOnPageChangeListener extends ViewPager.SimpleOnPageChangeListener {

        private int currentPage;

        @Override
        public void onPageSelected(int position) {
            currentPage = position;
            currentitem = position;
        }

        public int getCurrentPage() {
            return currentPage;
        }
    }

    /*
    *
    */
    public class DepthPageTransformer implements ViewPager.PageTransformer {


        public void transformPage(View view, float position) {
            int pageWidth = view.getWidth();

            if (position < -1) { // [-Infinity,-1)
                // This page is way off-screen to the left.
                view.setAlpha(0);

            } else if (position <= 0) { // [-1,0]
                // Use the default slide transition when moving to the left page
                view.setAlpha(1);
                view.setTranslationX(0);
                view.setScaleX(1);
                view.setScaleY(1);

            } else if (position <= 1) { // (0,1]
                // Fade the page out.
                view.setAlpha(1 - position);

                // Counteract the default slide transition
                view.setTranslationX(pageWidth * -position);

                // Scale the page down (between MIN_SCALE and 1)
                float scaleFactor = MIN_SCALE
                        + (1 - MIN_SCALE) * (1 - Math.abs(position));
                view.setScaleX(scaleFactor);
                view.setScaleY(scaleFactor);

            } else { // (1,+Infinity]
                // This page is way off-screen to the right.
                view.setAlpha(0);
            }
        }
    }


}


