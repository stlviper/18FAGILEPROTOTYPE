package fdasearch.vencore.com.fdasearch.utils;

/**
 * Created by komi on 1/1/15.
 */
public class DrawerItem {

    public int itemId = -1;
    public String itemName;
}
