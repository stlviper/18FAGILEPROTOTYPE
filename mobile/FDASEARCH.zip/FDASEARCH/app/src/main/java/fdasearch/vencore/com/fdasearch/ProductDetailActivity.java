package fdasearch.vencore.com.fdasearch;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import fdasearch.vencore.com.fdasearch.utils.MainApplication;

/**
 * Created by komi on 6/24/15.
 */
public class ProductDetailActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextView recallNumber;
    private TextView recallReason;
    private TextView description;
    private TextView classificcation;
    private TextView codeInfo;
    private TextView distributionQty;
    private TextView eventId;
    private TextView productType;
    private TextView status;
    private TextView recallingFirm;
    private TextView state;
    private TextView city;
    private TextView country;
    private TextView recallInitiationDate;
    private TextView distributionPattern;
    private TextView initialFirmNotification;

    private Product mProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        setContentView(R.layout.product_detail);

        //setup toolbar
        toolbar = (Toolbar) findViewById(R.id.app_bar);
        (findViewById(R.id.product_recall_linear)).setVisibility(View.VISIBLE);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Get product to be displayed
        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.getString(MainApplication.PRODUCT) != null) {
            String type = bundle.getString(MainApplication.PRODUCT);
            mProduct = MainApplication.gson.fromJson(type, Product.class);

        }

        //Initialize the product fields
        recallNumber = (TextView) findViewById(R.id.product_recall_number_view);
        recallReason = (TextView) findViewById(R.id.product_recall_reason_view);
        classificcation = (TextView) findViewById(R.id.product_classification_view);
        codeInfo = (TextView) findViewById(R.id.product_code_info_view);
        description = (TextView) findViewById(R.id.product_description);
        distributionQty = (TextView) findViewById(R.id.product_distribution_quantity_view);
        eventId = (TextView) findViewById(R.id.product_event_id_view);
        productType = (TextView) findViewById(R.id.product_type_view);
        status = (TextView) findViewById(R.id.product_status_view);
        recallingFirm = (TextView) findViewById(R.id.product_recalling_firm_view);
        state = (TextView) findViewById(R.id.product_status_view);
        city = (TextView) findViewById(R.id.product_city_view);
        country = (TextView) findViewById(R.id.product_country_view);
        recallInitiationDate = (TextView) findViewById(R.id.product_recall_initiation_view);
        distributionPattern = (TextView) findViewById(R.id.product_distribution_pattern_view);
        initialFirmNotification = (TextView) findViewById(R.id.product_initial_notification_view);


        //Update fields with current product value
        recallNumber.setText(mProduct.getRecall_number());
        recallReason.setText(mProduct.getReason_for_recall());
        classificcation.setText(mProduct.getClassification());
        codeInfo.setText(mProduct.getCode_info());
        distributionQty.setText(mProduct.getProduct_quantity());
        eventId.setText(mProduct.getEvent().getEvent_id());
        productType.setText(mProduct.getEvent().getProduct_type());
        status.setText(mProduct.getEvent().getStatus());
        recallingFirm.setText(mProduct.getEvent().getRecalling_firm());
        state.setText(mProduct.getEvent().getState());
        city.setText(mProduct.getEvent().getCity());
        country.setText(mProduct.getEvent().getCountry());
        recallInitiationDate.setText(mProduct.getEvent().getRecall_initiation_date());
        distributionPattern.setText(mProduct.getEvent().getDistribution_pattern());
        initialFirmNotification.setText(mProduct.getEvent().getRecall_initiation_date());
        description.setText(mProduct.getProduct_description());


    }

    /*
     *
     */
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_welcome, menu);

        return true;
    }

    /*
    *
    */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent i;
        switch (item.getItemId()) {

            case android.R.id.home:
                i = new Intent(this, MapActivity.class);
                startActivity(i);

                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
