package fdasearch.vencore.com.fdasearch;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

/**
 * Created by komi on 6/24/15.
 */
public class MyItem implements ClusterItem {
    private LatLng mPosition;
    private String mTitle;

    public MyItem(LatLng position) {
        mPosition = position;
    }

    @Override
    public LatLng getPosition() {
        return mPosition;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }
}