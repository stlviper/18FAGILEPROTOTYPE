package fdasearch.vencore.com.fdasearch.utils;

import android.app.Application;
import android.graphics.Bitmap.CompressFormat;

import com.google.android.gms.maps.model.LatLng;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.gson.Gson;

import fdasearch.vencore.com.fdasearch.SearchCriteria;


/**
 * Example application for adding an image cache to Volley.
 *
 * @author Komi Gnatiko
 */
public class MainApplication extends Application {

    public static final String SEARCHURL = " http://54.208.248.243/recallInfoMapView?";
    public static final String MAP_URL = "http://54.208.248.243/mapview?";
    //public static final String SEARCHURL = " http://agiledemo.vencore.com/recallInfoMapView?";
    // public static final String MAP_URL = "http://agiledemo.vencore.com/mapview?";
    public static final String SEARCHURL_PRODUCT = "product_type";
    public static final String SEARCHURL_LOCATION = "locations";
    public static final String DATE_RANGE = "daterange";
    public static final String KEY_TERM = "key_term";
    public static final String STATE = "state";
    public static final String PRODUCT = "product";
    public static final String POSITION = "position";
    public static final String PRODUCT_LIST = "product list";
    public static final String PRODUCT_DRUG = "Drug";
    public static final String PRODUCT_FOOD = "Food";
    public static final String PRODUCT_DEVICE = "Device";
    public static final BiMap<String, String> stateInfo = HashBiMap.create();
    public static final BiMap<String, LatLng> stateCoord = HashBiMap.create();
    public static final Gson gson = new Gson();
    public static final String TAG = "FDA Search";
    public static SearchCriteria mCriteria = new SearchCriteria();
    private static int DISK_IMAGECACHE_SIZE = 1024 * 1024 * 10;
    private static CompressFormat DISK_IMAGECACHE_COMPRESS_FORMAT = CompressFormat.PNG;
    private static int DISK_IMAGECACHE_QUALITY = 100;  //PNG is lossless so quality is ignored but must be provided

    @Override
    public void onCreate() {

        init();
        setupStates();
    }

    /**
     * Intialize the request manager and the image cache
     */
    private void init() {

        RequestManager.init(this);
        createImageCache();
    }

    /**
     * Create the image cache.
     */
    private void createImageCache() {
        ImageCacheManager.getInstance().init(this,
                this.getPackageCodePath()
                , DISK_IMAGECACHE_SIZE
                , DISK_IMAGECACHE_COMPRESS_FORMAT
                , DISK_IMAGECACHE_QUALITY);
    }

    /*
     * Hard coded states Abbreviation and Coordinate instead of slow reverse geo coding
     */
    private void setupStates() {


        stateInfo.put("Alabama", "AL");
        stateInfo.put("Alaska", "AK");
        stateInfo.put("Arizona", "AZ");
        stateInfo.put("Arkansas", "AR");
        stateInfo.put("California", "CA");
        stateInfo.put("Colorado", "CO");
        stateInfo.put("Connecticut", "CT");
        stateInfo.put("Delaware", "DE");
        stateInfo.put("Florida", "FL");
        stateInfo.put("Georgia", "GA");
        stateInfo.put("Hawaii", "HI");
        stateInfo.put("Idaho", "ID");
        stateInfo.put("Illinois", "IL");
        stateInfo.put("Indiana", "IN");
        stateInfo.put("Iowa", "IA");
        stateInfo.put("Kansas", "KS");
        stateInfo.put("Kentucky", "KY");
        stateInfo.put("Louisiana", "LA");
        stateInfo.put("Maine", "ME");
        stateInfo.put("Maryland", "MD");
        stateInfo.put("Massachusetts", "MA");
        stateInfo.put("Michigan", "MI");
        stateInfo.put("Minnesota", "MN");
        stateInfo.put("Mississippi", "MS");
        stateInfo.put("Missouri", "MO");
        stateInfo.put("Montana", "MT");
        stateInfo.put("Nebraska", "NE");
        stateInfo.put("Nevada", "NV");
        stateInfo.put("New Hampshire", "NH");
        stateInfo.put("New Jersey", "NJ");
        stateInfo.put("New Mexico", "NM");
        stateInfo.put("New York", "NY");
        stateInfo.put("North Carolina", "NC");
        stateInfo.put("North Dakota", "ND");
        stateInfo.put("Ohio", "OH");
        stateInfo.put("Oklahoma", "OK");
        stateInfo.put("Oregon", "OR");
        stateInfo.put("Pennsylvania", "PA");
        stateInfo.put("Rhode Island", "RI");
        stateInfo.put("South Carolina", "SC");
        stateInfo.put("South Dakota", "SD");
        stateInfo.put("Tennessee", "TN");
        stateInfo.put("Texas", "TX");
        stateInfo.put("Utah", "UT");
        stateInfo.put("Vermont", "VT");
        stateInfo.put("Virginia", "VA");
        stateInfo.put("Washington", "WA");
        stateInfo.put("Washington DC", "DC");
        stateInfo.put("West Virginia", "WV");
        stateInfo.put("Wisconsin", "WI");
        stateInfo.put("Wyoming", "WY");


        stateCoord.put("AL", (new LatLng(32.795163, -86.362133)));
        stateCoord.put("AK", (new LatLng(65.484690, -151.567988)));
        stateCoord.put("AZ", (new LatLng(34.512931, -111.694701)));
        stateCoord.put("AR", (new LatLng(34.968283, -92.147858)));
        stateCoord.put("CA", (new LatLng(37.411626, -120.272944)));
        stateCoord.put("CO", (new LatLng(39.142935, -105.501129)));
        stateCoord.put("CT", (new LatLng(41.627685, -72.681976)));
        stateCoord.put("DE", (new LatLng(39.023730, -75.499945)));
        stateCoord.put("FL", (new LatLng(27.408624, -81.473395)));
        stateCoord.put("GA", (new LatLng(32.372441, -83.239455)));
        stateCoord.put("HI", (new LatLng(19.624007, -155.423091)));
        stateCoord.put("ID", (new LatLng(44.703578, -115.010350)));
        stateCoord.put("IL", (new LatLng(40.841008, -88.937169)));
        stateCoord.put("IN", (new LatLng(39.563247, -85.974358)));
        stateCoord.put("IA", (new LatLng(41.848357, -93.439236)));
        stateCoord.put("KS", (new LatLng(38.910306, -98.289865)));
        stateCoord.put("KY", (new LatLng(37.587608, -84.938772)));
        stateCoord.put("LA", (new LatLng(31.302497, -92.304760)));
        stateCoord.put("ME", (new LatLng(45.418047, -69.231897)));
        stateCoord.put("MD", (new LatLng(39.211776, -76.886641)));
        stateCoord.put("MA", (new LatLng(42.380240, -72.083642)));
        stateCoord.put("MI", (new LatLng(43.399210, -84.485979)));
        stateCoord.put("MN", (new LatLng(45.954347, -94.672888)));
        stateCoord.put("MS", (new LatLng(32.926959, -89.377342)));
        stateCoord.put("MO", (new LatLng(38.614362, -92.925991)));
        stateCoord.put("MT", (new LatLng(46.972960, -108.523177)));
        stateCoord.put("NE", (new LatLng(41.833202, -100.455438)));
        stateCoord.put("NV", (new LatLng(39.441560, -117.121937)));
        stateCoord.put("NH", (new LatLng(43.890489, -71.571683)));
        stateCoord.put("NJ", (new LatLng(40.021120, -74.593786)));
        stateCoord.put("NM", (new LatLng(34.592389, -105.899726)));
        stateCoord.put("NY", (new LatLng(40.707477, -73.917883)));
        stateCoord.put("NC", (new LatLng(35.402836, -79.116731)));
        stateCoord.put("ND", (new LatLng(47.169970, -100.318745)));
        stateCoord.put("OH", (new LatLng(40.424945, -82.345156)));
        stateCoord.put("OK", (new LatLng(35.318036, -96.810431)));
        stateCoord.put("OR", (new LatLng(44.086691, -120.609510)));
        stateCoord.put("PA", (new LatLng(40.828541, -77.475609)));
        stateCoord.put("RI", (new LatLng(41.716129, -71.614941)));
        stateCoord.put("SC", (new LatLng(33.661635, -80.872880)));
        stateCoord.put("SD", (new LatLng(44.417081, -99.560519)));
        stateCoord.put("TN", (new LatLng(35.883946, -86.269737)));
        stateCoord.put("TX", (new LatLng(31.955659, -99.011169)));
        stateCoord.put("UT", (new LatLng(38.963638, -111.244904)));
        stateCoord.put("VT", (new LatLng(43.911341, -72.677139)));
        stateCoord.put("VA", (new LatLng(37.734529, -78.502976)));
        stateCoord.put("WA", (new LatLng(47.103796, -119.966249)));
        stateCoord.put("DC", (new LatLng(38.909768, -77.013708)));
        stateCoord.put("WV", (new LatLng(38.757580, -80.934254)));
        stateCoord.put("WI", (new LatLng(44.770700, -90.084884)));
        stateCoord.put("WY", (new LatLng(43.200868, -107.702882)));
    }
}