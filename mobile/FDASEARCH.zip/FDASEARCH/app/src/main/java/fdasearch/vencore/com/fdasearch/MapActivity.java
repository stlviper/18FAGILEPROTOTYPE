package fdasearch.vencore.com.fdasearch;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.gson.reflect.TypeToken;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import fdasearch.vencore.com.fdasearch.fragments.NavigationDrawerFragment;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;
import fdasearch.vencore.com.fdasearch.utils.RequestManager;


/**
 * Created by komi Gnatiko on 6/23/15.
 */
public class MapActivity extends AppCompatActivity implements OnMapReadyCallback
        // ,LocationListener
{

    private MapFragment mMap;
    private LatLngBounds bounds;
    private ClusterManager<MyItem> mClusterManager;
    //private LatLng currentLocation ;
    private List<StateMapResult> productList;
    private SearchCriteria searchItems;
    private HashMap<MyItem, StateMapResult> markerTag;
    private MyItem currentMyItem;
    private Toolbar toolbar;
    private NavigationDrawerFragment drawerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        invalidateOptionsMenu();
        setContentView(R.layout.map_activity);

        //setup toolbar
        toolbar = (Toolbar) findViewById(R.id.app_bar_map);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //setup drawer
        drawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.drawer_fragment2);
        drawerFragment.setup(R.id.drawer_fragment2, (DrawerLayout) findViewById(R.id.drawer_layout2), toolbar);


        //setup map
        mMap = (MapFragment) getFragmentManager().findFragmentById(R.id.mMap);
        mMap.getMapAsync(this);
        productList = new ArrayList<StateMapResult>();

        searchItems = new SearchCriteria();
        searchItems.addProduct(MainApplication.PRODUCT_FOOD);
        searchItems.addProduct(MainApplication.PRODUCT_DRUG);
        searchItems.addProduct(MainApplication.PRODUCT_DEVICE);
        getSearchResults();


    }

    /*
     *
    */
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_welcome, menu);

        return true;
    }

    /*
    *
    */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent i;
        switch (item.getItemId()) {

            case android.R.id.home:

                return true;
            case R.id.action_key_Search:
                i = new Intent(this, SearchActivity.class);
                startActivity(i);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /*
    *
    */
    @Override
    public void onMapReady(GoogleMap googleMap) {

        //googleMap.setMyLocationEnabled(true);

        googleMap.getUiSettings().setZoomControlsEnabled(true);

        googleMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {

            }
        });
        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                marker.showInfoWindow();
                return false;
            }
        });
        googleMap.setOnInfoWindowClickListener(
                new GoogleMap.OnInfoWindowClickListener() {
                    public void onInfoWindowClick(Marker marker) {
                        getDetail(currentMyItem);
                    }
                });

    }

    /*
    *
    */
    private void getSearchResults() {
        String url = MainApplication.MAP_URL;
        boolean isProd = false;
        String prd = "";

        //setup the selected product type
        for (int i = 0; i < searchItems.getProductType().size(); i++) {
            isProd = true;
            if (i == 0)
                prd = MainApplication.SEARCHURL_PRODUCT + "=" + searchItems.getProductType().get(i).toLowerCase();
            else
                prd += "&" + MainApplication.SEARCHURL_PRODUCT + "=" + searchItems.getProductType().get(i).toLowerCase();
        }

        //setup the date range
        if (searchItems.getStartDate() != null && searchItems.getStartDate().length() > 0 && searchItems.getEndDate() != null) {

            url += "&" + MainApplication.DATE_RANGE + "=["
                    + searchItems.getStartDate()
                    + "-TO-"
                    + searchItems.getEndDate()
                    + "]";
        }

        JsonArrayRequest jsObjRequest = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        if (response != null) {

                            Type listType = new TypeToken<ArrayList<StateMapResult>>() {
                            }.getType();
                            List<StateMapResult> res = MainApplication.gson.fromJson(response.toString(), listType);
                            productList.addAll(res);
                            setUpCluster();
                        }
                    } //catch (JSONException e) { e.printStackTrace(); }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        RequestManager.getRequestQueue().add(jsObjRequest);
    }

    /*
     *
    */
    private void setUpCluster() {
        // Declare a variable for the cluster manager.

        GoogleMap mGoogleMap = mMap.getMap();

        mClusterManager = new ClusterManager<MyItem>(this, mGoogleMap);

        mClusterManager.setRenderer(new MyClusterRenderer(getApplicationContext(), mGoogleMap, mClusterManager));

        // Point the map's listeners at the listeners implemented by the cluster
        // manager.
        mGoogleMap.setOnCameraChangeListener(mClusterManager);
        mGoogleMap.setOnMarkerClickListener(mClusterManager);
        mClusterManager.setOnClusterInfoWindowClickListener(new ClusterManager.OnClusterInfoWindowClickListener<MyItem>() {
            @Override
            public void onClusterInfoWindowClick(Cluster<MyItem> myItemCluster) {


            }
        });
        mClusterManager.setOnClusterItemClickListener(new ClusterManager.OnClusterItemClickListener<MyItem>() {
            @Override
            public boolean onClusterItemClick(MyItem myItem) {
                currentMyItem = myItem;
                return false;
            }
        });
        // Add cluster items (markers) to the cluster manager.
        MarkerUpdateTask task = new MarkerUpdateTask();

        task.execute("");

    }

    /*
     *
    */
    private void getDetail(MyItem mItem) {
        StateMapResult prod = markerTag.get(mItem);
        searchItems.clearStates();
        searchItems.addStated(prod.getState());
        MainApplication.mCriteria = searchItems;
        if (prod != null) {
            Intent i = new Intent(getApplicationContext(), ProductSummaryActivity.class);
            startActivityForResult(i, 100);

        }
    }

    /*
     *
    */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                return super.onKeyDown(keyCode, event);

            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    /*
     *  Load the markers off the Main thread
    */
    private class MarkerUpdateTask extends AsyncTask<String, Integer, Boolean> {
        @Override
        protected Boolean doInBackground(String... photos) {

            int count = 0;

            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            // Add ten cluster items in close proximity, for purposes of this example.
            markerTag = new HashMap<MyItem, StateMapResult>();
            HashMap<String, Double> moveCoord = new HashMap<String, Double>();
            for (StateMapResult p : productList) {


                LatLng coord = MainApplication.stateCoord.get(p.getState());

                if (coord != null) {
                    builder.include(coord);
                    if (bounds == null) bounds = new LatLngBounds(coord, coord);
                    MyItem offsetItem = new MyItem(coord);
                    offsetItem.setTitle(p.getState() + ": " + p.getTotal());
                    String snip = "";
                    for (int i = 0; i < p.getValue().size(); i++) {
                        snip += p.getValue().get(i).getType() + ": " + p.getValue().get(i).getCount();
                        if (i < (p.getValue().size() - 1)) snip += " | ";
                    }
                    offsetItem.setTitle(p.getState() + ": " + p.getTotal() + " | " + snip);
                    markerTag.put(offsetItem, p);
                    mClusterManager.addItem(offsetItem);
                }
            }
            if (bounds != null) {
                bounds = builder.build();

            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            if (values[0] % 10 == 0) {

                mClusterManager.cluster();
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {

            findViewById(R.id.progress).setVisibility(View.GONE);
            if (bounds != null) {
                int padding = 180; // offset from edges of the map in pixels
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                if (mMap.getMap() != null) mMap.getMap().animateCamera(cu);
            }
        }
    }


}