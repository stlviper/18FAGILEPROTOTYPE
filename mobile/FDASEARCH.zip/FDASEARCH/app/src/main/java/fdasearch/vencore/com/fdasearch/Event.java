package fdasearch.vencore.com.fdasearch;

/**
 * Created by komi on 6/23/15.
 */
public class Event {

    private String event_id;
    private String product_type;
    private String status;
    private String recalling_firm;
    private String state;
    private String city;
    private String country;
    private String recall_initiation_date;
    private String voluntary_mandated;
    private String distribution_pattern;
    private String initial_firm_notification;

    public Event() {

    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getInitial_firm_notification() {
        return initial_firm_notification;
    }

    public void setInitial_firm_notification(String initial_firm_notification) {
        this.initial_firm_notification = initial_firm_notification;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRecalling_firm() {
        return recalling_firm;
    }

    public void setRecalling_firm(String recalling_firm) {
        this.recalling_firm = recalling_firm;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRecall_initiation_date() {
        return recall_initiation_date;
    }

    public void setRecall_initiation_date(String recall_initiation_date) {
        this.recall_initiation_date = recall_initiation_date;
    }

    public String getVoluntary_mandated() {
        return voluntary_mandated;
    }

    public void setVoluntary_mandated(String voluntary_mandated) {
        this.voluntary_mandated = voluntary_mandated;
    }

    public String getDistribution_pattern() {
        return distribution_pattern;
    }

    public void setDistribution_pattern(String distribution_pattern) {
        this.distribution_pattern = distribution_pattern;
    }

    @Override
    public String toString() {
        return "Event{" +
                "event_id='" + event_id + '\'' +
                ", product_type='" + product_type + '\'' +
                ", status='" + status + '\'' +
                ", recalling_firm='" + recalling_firm + '\'' +
                ", state='" + state + '\'' +
                ", city='" + city + '\'' +
                ", country='" + country + '\'' +
                ", recall_initiation_date='" + recall_initiation_date + '\'' +
                ", voluntary_mandated='" + voluntary_mandated + '\'' +
                ", distribution_pattern='" + distribution_pattern + '\'' +
                ", initial_firm_notification='" + initial_firm_notification + '\'' +
                '}';
    }
}
