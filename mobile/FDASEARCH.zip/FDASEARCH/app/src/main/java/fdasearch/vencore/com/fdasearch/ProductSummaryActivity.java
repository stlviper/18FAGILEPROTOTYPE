package fdasearch.vencore.com.fdasearch;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import fdasearch.vencore.com.fdasearch.adapters.SummaryRecyclerViewAdapter;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;
import fdasearch.vencore.com.fdasearch.utils.RequestManager;

;

/**
 * Created by komi on 6/29/15.
 */
public class ProductSummaryActivity extends AppCompatActivity {
    SearchCriteria search;
    private Toolbar toolbar;
    private RecyclerView listView;
    private List<Product> prodList;
    private SummaryRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        invalidateOptionsMenu();
        setContentView(R.layout.summary_activity);
        toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (RecyclerView) findViewById(R.id.prod_list);
        listView.setLayoutManager(new LinearLayoutManager(this));

        prodList = new ArrayList<Product>();

        search = MainApplication.mCriteria;

        //Get list of products from web service
        pullKeyResult();


    }


    /*
    *
    */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.menu_welcome, menu);
        (menu.findItem(R.id.action_key_Search)).setVisible(false);

        return true;
    }

    /*
    *
    */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {

            case android.R.id.home:

                Intent returnIntent = new Intent();
                setResult(RESULT_CANCELED, returnIntent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    /*
    *
    */
    public void pullKeyResult() {
        String url = MainApplication.SEARCHURL;
        boolean isProd = false;
        String prd = "";
        if (search != null && search.getProductType() != null) {
            for (int i = 0; i < search.getProductType().size(); i++) {
                isProd = true;
                if (i == 0)
                    prd = MainApplication.SEARCHURL_PRODUCT + "=" + search.getProductType().get(i).toLowerCase();
                else
                    prd += "&" + MainApplication.SEARCHURL_PRODUCT + "=" + search.getProductType().get(i).toLowerCase();
            }
        }
        url += prd;

        if (search != null && search.getSearchKey() != null) {
            if (isProd) url += "&";
            url += MainApplication.KEY_TERM
                    + "=" + search.getSearchKey();
        }
        if (search != null && search.getStartDate() != null && search.getStartDate().length() > 0 && search.getEndDate() != null) {

            url += "&" + MainApplication.DATE_RANGE + "=["
                    + search.getStartDate()
                    + "+TO+"
                    + search.getEndDate()
                    + "]";

        }

        Log.i(MainApplication.TAG, "url is " + url);
        JsonObjectRequest jsObjRequest =
                new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            if (response.getString("results") != null) {
                                JSONArray data = (JSONArray) response.get("results");
                                Type listType = new TypeToken<ArrayList<Product>>() {
                                }.getType();
                                List<Product> res = MainApplication.gson.fromJson(data.toString(), listType);

                                prodList.addAll(res);
                                if (prodList.size() < 1) {
                                    (findViewById(R.id.search_progress_bar)).setVisibility(View.GONE);
                                    (findViewById(R.id.linNorequest)).setVisibility(View.VISIBLE);
                                } else {
                                    (findViewById(R.id.search_progress_bar)).setVisibility(View.GONE);
                                    (findViewById(R.id.linNorequest)).setVisibility(View.GONE);
                                    setTitle("Summary ("+prodList.size()+")");
                                    populateList();
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i(MainApplication.TAG, "URL Volley error:  " + error.getMessage());
                        (findViewById(R.id.search_progress_bar)).setVisibility(View.GONE);
                        (findViewById(R.id.linNorequest)).setVisibility(View.VISIBLE);

                    }
                }
                );
        RequestManager.getRequestQueue().add(jsObjRequest);
    }

    /*
    * populate the keyword product search result  list
    */
    private boolean populateList() {

        boolean ret = false;

        if (prodList != null && prodList.size() > 0) {

            (findViewById(R.id.linNorequest)).setVisibility(View.GONE);
            if (adapter == null) {

                adapter = new SummaryRecyclerViewAdapter(this, prodList);
                adapter.SetOnItemClickListener(new SummaryRecyclerViewAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(View v, int position) {
                        productDetail(prodList.get(position));
                    }
                });
                listView.setAdapter(adapter);

            } else {
                adapter.notifyDataSetChanged();
            }

        }

        return ret;


    }

    /*
    *
    */
    private void productDetail(Product prod) {

        Intent in = new Intent(getApplicationContext(), ProductViewPagerActivity.class);

        MainApplication.mCriteria = search;
        String param = MainApplication.gson.toJson(prod);
        in.putExtra(MainApplication.PRODUCT, param);
        startActivity(in);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                MainApplication.mCriteria.setSearchKey(null);
                return super.onKeyDown(keyCode, event);

            default:
                return super.onKeyDown(keyCode, event);
        }
    }

}

