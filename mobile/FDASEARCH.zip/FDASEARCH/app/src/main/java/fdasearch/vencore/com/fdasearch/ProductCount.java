package fdasearch.vencore.com.fdasearch;

/**
 * Created by komi on 6/30/15.
 * Class for MapView display
 */
public class ProductCount {
    String type;
    int count;

    public ProductCount() {

    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
