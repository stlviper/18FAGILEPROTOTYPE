package fdasearch.vencore.com.fdasearch.fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import fdasearch.vencore.com.fdasearch.Product;
import fdasearch.vencore.com.fdasearch.R;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;


public class ProductSlidePagerFragment extends Fragment {

    /**
     * The argument key for the page number this fragment represents.
     */
    public static final String ARG_PAGE = "page";


    /**
     * The fragment's page number, which is set to the argument value for {@link #ARG_PAGE}.
     */
    private int requestTypeNumber;


    private Context mContext;
    private Product mProduct;
    private TextView recallNumber;
    private TextView recallReason;
    private TextView description;
    private TextView classificcation;
    private TextView codeInfo;
    private TextView distributionQty;
    private TextView eventId;
    private TextView productType;
    private TextView status;
    private TextView recallingFirm;
    private TextView state;
    private TextView city;
    private TextView country;
    private TextView recallInitiationDate;
    private TextView voluntaryMandated;
    private TextView distributionPattern;
    private TextView initialFirmNotification;
    private Toolbar toolbar;


    public ProductSlidePagerFragment() {
    }

    /**
     * Factory method for this fragment class. Constructs a new fragment for the given page number.
     */
    public static ProductSlidePagerFragment create(int pageNumber, String type) {
        ProductSlidePagerFragment fragment = new ProductSlidePagerFragment();
        Bundle args = new Bundle();


        args.putInt(ARG_PAGE, pageNumber);
        args.putString(MainApplication.PRODUCT, type);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mProduct = MainApplication.gson.fromJson(getArguments().getString(MainApplication.PRODUCT), Product.class);
        mContext = getActivity().getApplicationContext();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout containing a title and body text.
        ViewGroup rootView = (ViewGroup) inflater
                .inflate(R.layout.product_detail, container, false);

        toolbar = (Toolbar) rootView.findViewById(R.id.app_bar);
        (rootView.findViewById(R.id.product_recall_linear)).setVisibility(View.VISIBLE);


        recallNumber = (TextView) rootView.findViewById(R.id.product_recall_number_view);
        recallReason = (TextView) rootView.findViewById(R.id.product_recall_reason_view);
        classificcation = (TextView) rootView.findViewById(R.id.product_classification_view);
        codeInfo = (TextView) rootView.findViewById(R.id.product_code_info_view);
        distributionQty = (TextView) rootView.findViewById(R.id.product_distribution_quantity_view);
        eventId = (TextView) rootView.findViewById(R.id.product_event_id_view);
        productType = (TextView) rootView.findViewById(R.id.product_type_view);
        status = (TextView) rootView.findViewById(R.id.product_status_view);
        recallingFirm = (TextView) rootView.findViewById(R.id.product_recalling_firm_view);
        state = (TextView) rootView.findViewById(R.id.product_status_view);
        city = (TextView) rootView.findViewById(R.id.product_city_view);
        country = (TextView) rootView.findViewById(R.id.product_country_view);
        recallInitiationDate = (TextView) rootView.findViewById(R.id.product_recall_initiation_view);
        distributionPattern = (TextView) rootView.findViewById(R.id.product_distribution_pattern_view);
        initialFirmNotification = (TextView) rootView.findViewById(R.id.product_initial_notification_view);


        recallNumber.setText(mProduct.getRecall_number());
        recallReason.setText(mProduct.getReason_for_recall());
        classificcation.setText(mProduct.getClassification());
        codeInfo.setText(mProduct.getCode_info());
        distributionQty.setText(mProduct.getProduct_quantity());
        eventId.setText(mProduct.getEvent().getEvent_id());
        productType.setText(mProduct.getEvent().getCity());
        status.setText(mProduct.getEvent().getStatus());
        recallingFirm.setText(mProduct.getEvent().getRecalling_firm());
        state.setText(mProduct.getEvent().getState());
        city.setText(mProduct.getEvent().getCity());
        country.setText(mProduct.getEvent().getCountry());
        recallInitiationDate.setText(mProduct.getEvent().getRecall_initiation_date());
        distributionPattern.setText(mProduct.getEvent().getDistribution_pattern());
        initialFirmNotification.setText(mProduct.getEvent().getRecall_initiation_date());
        return rootView;
    }

    /**
     * Returns the page number represented by this fragment object.
     */
    public int getPageNumber() {
        return requestTypeNumber;
    }


    /**
     * ******************************************************************************************************
     */

}

