package fdasearch.vencore.com.fdasearch;

import java.util.List;

/**
 * Created by komi on 6/30/15.
 */
public class StateMapResult {
    private String state;
    private int total;
    private List<ProductCount> value;

    public StateMapResult() {

    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<ProductCount> getValue() {
        return value;
    }

    public void setValue(List<ProductCount> value) {
        this.value = value;
    }
}
