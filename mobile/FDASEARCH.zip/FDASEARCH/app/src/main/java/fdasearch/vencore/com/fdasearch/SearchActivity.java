package fdasearch.vencore.com.fdasearch;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.github.clans.fab.FloatingActionButton;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import fdasearch.vencore.com.fdasearch.fragments.NavigationDrawerFragment;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;

/**
 * Created by komi on 6/22/15.
 */
public class SearchActivity extends AppCompatActivity {

    protected static final int REQUEST_OK = 1;
    private static final String START_DATE = "start";
    private static final String END_DATE = "end";
    static private MaterialEditText startDateSelected;
    static private MaterialEditText endDateSelected;
    boolean mIsLargeLayout;
    int currentOption = 0;
    private Toolbar toolbar;
    private NavigationDrawerFragment drawerFragment;
    private MaterialEditText productSelected;
    private FloatingActionButton searchButton;
    private FloatingActionButton voiceOption;
    private SearchCriteria mSearchCriteria;
    private LinearLayout voiceSearchView;
    private SearchView searchView;
    private TextView searchResult;
    /*
    *
    */
    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.search_option:
                    searchClicked();
                    break;
                case R.id.voice_option:
                    startListen();
                    (findViewById(R.id.mic_layout)).setVisibility(View.GONE);
                    searchResult.setText(R.string.listening);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();

        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            doMySearch(query);
        }
        setContentView(R.layout.search_activity);
        toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.drawer_fragment);
        drawerFragment.setup(R.id.drawer_fragment, (DrawerLayout) findViewById(R.id.drawer_layout1), toolbar);
        searchButton = (FloatingActionButton) findViewById(R.id.search_option);
        searchButton.setOnClickListener(clickListener);

        voiceOption = (FloatingActionButton) findViewById(R.id.voice_option);
        voiceOption.setOnClickListener(clickListener);

        mIsLargeLayout = getResources().getBoolean(R.bool.large_layout);
        voiceSearchView = (LinearLayout) findViewById(R.id.voice_search_view);
        mSearchCriteria = new SearchCriteria();

        setProducts();
        setStartDates();
        setEndDates();

        searchResult = (TextView) findViewById(R.id.voice_listen);

    }

    /*
     *
    */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_search, menu);
        SearchManager searchManager =
                (SearchManager) getSystemService(this.SEARCH_SERVICE);
        searchView =
                (SearchView) menu.findItem(R.id.action_key_Search).getActionView();
        searchView.setSearchableInfo(
                searchManager.getSearchableInfo(getComponentName()));


        searchView.setOnQueryTextListener(new android.widget.SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                doMySearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }

    /*
    *
    */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        Intent i;

        switch (item.getItemId()) {

            case android.R.id.home:
                i = new Intent(this, WelcomeActivity.class);
                startActivity(i);
                return true;
            case R.id.action_voice:
                startListen();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    /*
    *
    */
    private void setStartDates() {
        startDateSelected = (MaterialEditText) findViewById(R.id.date_start);
        startDateSelected.setClickable(true);
        startDateSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), START_DATE);
            }
        });


    }

    /*
    *
    */
    private void setEndDates() {
        endDateSelected = (MaterialEditText) findViewById(R.id.date_end);
        endDateSelected.setClickable(true);
        endDateSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), END_DATE);
            }
        });


    }

    /*
    *
    */
    private void showMyProductDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.product_type)
                .items(R.array.product_types)
                .itemsCallbackMultiChoice(null, new MaterialDialog.ListCallbackMultiChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, Integer[] which, CharSequence[] text) {
                        /**
                         * If you use alwaysCallMultiChoiceCallback(), which is discussed below,
                         * returning false here won't allow the newly selected check box to actually be selected.
                         * See the limited multi choice dialog example in the sample project for details.
                         **/
                        productSelected(text);
                        return true;
                    }
                })
                .positiveText(R.string.select)
                .show();
    }

    /*
    *
    */
    private void setProducts() {
        productSelected = (MaterialEditText) findViewById(R.id.product_selected);

        productSelected.setClickable(true);
        productSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMyProductDialog();
            }
        });


    }

    /*
    *
    */
    private void productSelected(CharSequence[] text) {
        mSearchCriteria.resetProducts();
        if (text != null && text.length > 0) {
            String prod = "";
            for (CharSequence cu : text) {
                prod += " \n " + cu.toString();
                mSearchCriteria.addProduct(cu.toString());


            }
            productSelected.setText(prod);
        } else {
            productSelected.setText("");
        }
    }

    /*
     * Reveal Voice search view
     */
    public void revealView(View myView, int startX, int startY) {

        int finalRadius = Math.max(myView.getWidth(), myView.getHeight());
        searchResult.setTextColor(getResources().getColor(R.color.text_color));
        // create the animator for this view (the start radius is zero)
        Animator anim =
                ViewAnimationUtils.createCircularReveal(myView, startX, startY, 0, finalRadius);

        // make the view visible and start the animation
        myView.setVisibility(View.VISIBLE);
        anim.start();
    }

    /*
     * Hide Voice search view
     */
    public void hideView(View view, int startX, int startY) {
        currentOption = 0;
        // previously visible view
        final View myView = view;

        // get the initial radius for the clipping circle
        int initialRadius = myView.getWidth();
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();

        float dpHeight = displayMetrics.heightPixels;
        float dpWidth = displayMetrics.widthPixels; /// displayMetrics.density;

        int width = (int) (dpWidth - 35 * displayMetrics.density);
        int height = (int) (56 * displayMetrics.density / 2);
        // create the animation (the final radius is zero)
        Animator anim =
                ViewAnimationUtils.createCircularReveal(myView, width, height, initialRadius, 0);

        // make the view invisible when the animation is done
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                myView.setVisibility(View.INVISIBLE);
            }
        });

// start the animation
        anim.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OK && resultCode == RESULT_OK) {
            ArrayList<String> thingsYouSaid = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            searchResult.setText(thingsYouSaid.get(0));
            checkVoiceString(thingsYouSaid.get(0));
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();

            float dpWidth = displayMetrics.widthPixels;
            int width = (int) (dpWidth - 70 * displayMetrics.density);
            int height = (int) (56 * displayMetrics.density / 2);
            voiceSearchView.setBackgroundColor(getResources().getColor(R.color.white_color));
            currentOption = 1;
            revealView(voiceSearchView, width, height);
        }
    }

    /*
    *
    */
    private void startListen() {

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
        try {
            startActivityForResult(i, REQUEST_OK);
        } catch (Exception e) {
            Toast.makeText(this, "Error initializing speech to text engine.", Toast.LENGTH_LONG).show();
        }

    }

    /*
    *
    */
    private boolean checkVoiceString(String voice) {

        boolean ret = false;

        if (voice.contains("find")) {
            mSearchCriteria = new SearchCriteria();
            if (voice.contains(MainApplication.PRODUCT_FOOD.toLowerCase())) {
                mSearchCriteria.addProduct(MainApplication.PRODUCT_FOOD);
                ret = true;
            }
            if (voice.contains(MainApplication.PRODUCT_DEVICE.toLowerCase())) {
                mSearchCriteria.addProduct(MainApplication.PRODUCT_DEVICE);
                ret = true;
            }
            if (voice.contains(MainApplication.PRODUCT_DRUG.toLowerCase())) {
                ret = true;
                mSearchCriteria.addProduct(MainApplication.PRODUCT_DRUG);
            }


            String[] temp = getResources().getStringArray(R.array.us_states);
            for (int i = 0; i < temp.length; i++) {
                if (voice.contains(temp[i])) mSearchCriteria.addStated(temp[i]);
            }
        } else {
            mSearchCriteria = new SearchCriteria();
            mSearchCriteria.setSearchKey(voice);
            ret = true;
        }
        (findViewById(R.id.mic_layout)).setVisibility(View.VISIBLE);
        return ret;

    }

    /*
    *
    */
    private void searchClicked() {
        boolean cancel = false;

        //Voice search option
        if (currentOption == 1) {
            if (!checkVoiceString(searchResult.getText().toString())) {

                searchResult.setText("Tap mic to Try again.");
                searchResult.setTextColor(getResources().getColor(R.color.colorAccent));

                cancel = true;
            }

        } else {  //Form search option
            if (TextUtils.isEmpty(productSelected.getText().toString())) {
                productSelected.setError(getString(R.string.product_field_required));
                cancel = true;
            }
            if (cancel == false) {

                if (startDateSelected.getText().toString() != null)
                    mSearchCriteria.setStartDate(startDateSelected.getText().toString());
                if (endDateSelected.getText().toString() != null)
                    mSearchCriteria.setEndDate(endDateSelected.getText().toString());
            }
        }

        if (cancel == false) {
            if (currentOption == 1) hideView(voiceSearchView, 0, 0);
            Intent i = new Intent(getApplicationContext(), ProductSummaryActivity.class);
            MainApplication.mCriteria = mSearchCriteria;
            startActivityForResult(i, 101);
            ;
        }

    }

    /*
    *  Keyword search
    */
    private void doMySearch(String queryStr) {
        Intent i = new Intent(getApplicationContext(), ProductSummaryActivity.class);
        mSearchCriteria.setSearchKey(queryStr);
        if (mSearchCriteria.getStartDate() == null) {
            Calendar calendar = Calendar.getInstance();

            mSearchCriteria.setStartDate(calendar.get(Calendar.YEAR) + "-01-01");
            mSearchCriteria.setEndDate(calendar.get(Calendar.YEAR) + "-" +
                    (calendar.get(Calendar.MONTH) + 1) + "-" + calendar.get(Calendar.DATE));
        }
        MainApplication.mCriteria = mSearchCriteria;
        i.putExtra(MainApplication.KEY_TERM, queryStr);
        searchView.setQuery("", false);
        searchView.setIconified(true);
        startActivity(i);

    }

    /*
    *
    */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                if (currentOption == 1) {
                    int cX = ((findViewById(R.id.action_voice)).getLeft() + (findViewById(R.id.action_voice)).getRight()) / 2;
                    int cY = ((findViewById(R.id.action_voice)).getTop() + (findViewById(R.id.action_voice)).getBottom()) / 2;

                    hideView(voiceSearchView, cX, cY);
                    searchResult.setText(R.string.listening);
                    currentOption = 0;
                    return false;
                } else {
                    Intent i = new Intent(this, WelcomeActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    finish();
                    return false;
                }
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    /*
    *
    */
    protected void onDestroy() {

        super.onDestroy();

    }

    /*
     * Date picker dialog
     */
    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            String date = year + "/" + month + "/" + day;
            java.util.Date utilDate = null;


            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date chosen by the user
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = new GregorianCalendar(year, month, day);

            String date = year + "/" + month + "/" + day;
            java.util.Date utilDate = null;


            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            //utilDate = formatter.parse(date);


            if (getTag().equalsIgnoreCase(START_DATE)) {
                // Log.i(MainApplication.TAG, " sDATE  selected : " + year + " " + month);
                startDateSelected.setText(sdf.format(cal.getTime()));


            } else {
                endDateSelected.setText(sdf.format(cal.getTime()));

            }


        }
    }

}
