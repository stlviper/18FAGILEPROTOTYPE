package fdasearch.vencore.com.fdasearch.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

import fdasearch.vencore.com.fdasearch.R;
import fdasearch.vencore.com.fdasearch.utils.DrawerItem;


/**
 * Created by komi on 1/1/15.
 */
public class DrawerRecycleViewAdapter extends RecyclerView.Adapter<DrawerRecycleViewAdapter.MyViewHolder> {
    OnItemClickListener mItemClickListener;
    private LayoutInflater layout;
    private List<DrawerItem> optionList = Collections.emptyList();

    public DrawerRecycleViewAdapter(Context ct, List<DrawerItem> list) {

        layout = LayoutInflater.from(ct);
        this.optionList = list;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int i) {
        // create a new view
        View itemLayoutView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.drawer_list_item, parent, false);

        // create ViewHolder

        MyViewHolder viewHolder = new MyViewHolder(itemLayoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder viewHolder, int i) {

        viewHolder.name.setText(optionList.get(i).itemName);
        if (optionList.get(i).itemId > 0)
            viewHolder.image.setImageResource(optionList.get(i).itemId);
    }

    @Override
    public int getItemCount() {
        return optionList.size();
    }

    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name;
        ImageView image;

        public MyViewHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.drawerItemImage);
            name = (TextView) itemView.findViewById(R.id.drawerItemName);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (mItemClickListener != null) {

                mItemClickListener.onItemClick(v, getPosition());
            }
        }
    }

}
