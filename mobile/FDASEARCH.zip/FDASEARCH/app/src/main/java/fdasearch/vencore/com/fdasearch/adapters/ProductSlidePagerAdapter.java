package fdasearch.vencore.com.fdasearch.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import java.util.List;

import fdasearch.vencore.com.fdasearch.Product;
import fdasearch.vencore.com.fdasearch.fragments.ProductSlidePagerFragment;
import fdasearch.vencore.com.fdasearch.utils.MainApplication;


public class ProductSlidePagerAdapter extends FragmentStatePagerAdapter {
    private List<Product> theList;

    public ProductSlidePagerAdapter(FragmentManager fm, List<Product> list) {
        super(fm);
        theList = list;

    }

    @Override
    public Fragment getItem(int position) {


        return ProductSlidePagerFragment.create(position, MainApplication.gson.toJson(theList.get(position)));
    }

    @Override
    public int getCount() {
        return theList.size();
    }

    @Override
    public void destroyItem(View collection, int position, Object o) {
        View view = (View) o;
        ((ViewPager) collection).removeView(view);
        view = null;
    }

    public void deleteAll() {
        this.theList = null;
    }

}
