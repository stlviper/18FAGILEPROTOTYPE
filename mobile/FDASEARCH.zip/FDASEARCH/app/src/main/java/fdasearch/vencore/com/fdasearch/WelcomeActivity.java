package fdasearch.vencore.com.fdasearch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.github.clans.fab.FloatingActionButton;
import com.squareup.picasso.Picasso;


public class WelcomeActivity extends Activity {


    FloatingActionButton login;
    ImageView mainbackgroundView;
    /**
     * ********************************************************************************************
     */
    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i;

            switch (v.getId()) {
                case R.id.login_option:
                    i = new Intent(getApplicationContext(), MapActivity.class);
                    startActivity(i);
                    break;

            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_welcome);
        mainbackgroundView = (ImageView) findViewById(R.id.main_background);
        login = (FloatingActionButton) findViewById(R.id.login_option);
        login.setOnClickListener(clickListener);

        loadBitmap(R.drawable.headernew, mainbackgroundView);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_welcome, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        return super.onOptionsItemSelected(item);
    }

    public void loadBitmap(int resId, ImageView imageView) {


        DisplayMetrics display = getResources().getDisplayMetrics();
        Point size = new Point();
        //display.getSize(size);
        int width = display.widthPixels;
        int height = display.heightPixels;

        Uri uri = Uri.parse("android.resource://" + getPackageName() + "/drawable/headernew");
        Picasso.with(this).load(uri).resize(width, height).centerCrop().into(mainbackgroundView);
    }

}

