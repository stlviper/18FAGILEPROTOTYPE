package fdasearch.vencore.com.fdasearch.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fdasearch.vencore.com.fdasearch.MapActivity;
import fdasearch.vencore.com.fdasearch.R;
import fdasearch.vencore.com.fdasearch.SearchActivity;
import fdasearch.vencore.com.fdasearch.WelcomeActivity;
import fdasearch.vencore.com.fdasearch.adapters.DrawerRecycleViewAdapter;
import fdasearch.vencore.com.fdasearch.utils.DrawerItem;


public class NavigationDrawerFragment extends Fragment {
    public static final String PREF_NAME = "drawerPReferences";
    public static final String KEY_USER_LEARNED = "user_learned_drawer";
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    static Map<String, Integer> icons = new HashMap<String, Integer>();
    TextView usernameView;
    TextView emailView;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private View container;
    private boolean mUserlearned;
    private boolean mFromSavedInstance;
    private RecyclerView drawerList;
    private DrawerRecycleViewAdapter adapter;
    private ImageView profilePic;
    private String mParam1;
    private String mParam2;


    public NavigationDrawerFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NavigationDrawerFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NavigationDrawerFragment newInstance(String param1, String param2) {
        NavigationDrawerFragment fragment = new NavigationDrawerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public static void saveToPreferences(Context context, String prefName, String prefValue) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(prefName, prefValue);
        editor.apply();
    }

    public static String readFromPreferences(Context context, String prefName, String defaultValue) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, context.MODE_PRIVATE);
        return sharedPreferences.getString(prefName, defaultValue);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        mUserlearned = Boolean.valueOf(readFromPreferences(getActivity(), KEY_USER_LEARNED, "false"));

        if (savedInstanceState != null) {
            mFromSavedInstance = true;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View layout = inflater.inflate(R.layout.fragment_drawer, container, false);
        profilePic = (ImageView) layout.findViewById(R.id.drawer_profile_pic);
        usernameView = (TextView) layout.findViewById(R.id.drawer_profile_username);
        emailView = (TextView) layout.findViewById(R.id.drawer_profile_email);

        drawerList = (RecyclerView) layout.findViewById(R.id.drawer_recycle);
        drawerList.setLayoutManager(new LinearLayoutManager(getActivity().getApplicationContext()));

        setupList();
        return layout;

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    public void setup(int fragmentId, DrawerLayout drawer, Toolbar toolbar) {
        container = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawer;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), mDrawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                if (!mUserlearned) {
                    mUserlearned = true;
                    saveToPreferences(getActivity(), KEY_USER_LEARNED, mUserlearned + "");
                }
                getActivity().invalidateOptionsMenu();
            }
        };

        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

    }

    private void setupList() {
        String[] list = getActivity().getResources().getStringArray(R.array.menu_option_array);
        final List<DrawerItem> dList = new ArrayList<DrawerItem>();
        icons.put("Home", R.drawable.ic_home_black_24dp);
        icons.put("Search", R.drawable.ic_search_black_24dp);
        icons.put("Map view", R.drawable.ic_map_616161_24dp);

        for (String s : list) {

            DrawerItem d = new DrawerItem();
            d.itemName = s;
            d.itemId = (int) icons.get(d.itemName);
            dList.add(d);
        }
        adapter = new DrawerRecycleViewAdapter(getActivity().getApplicationContext(), dList);
        adapter.SetOnItemClickListener(new DrawerRecycleViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {
                Intent i;
                mDrawerLayout.closeDrawers();
                if (dList.get(position).itemName.equalsIgnoreCase("Home")) {
                    i = new Intent(getActivity(), WelcomeActivity.class);
                    startActivity(i);
                } else if (dList.get(position).itemName.equalsIgnoreCase("Search")) {
                    i = new Intent(getActivity(), SearchActivity.class);
                    startActivity(i);
                } else if (dList.get(position).itemName.equalsIgnoreCase("Map view")) {
                    i = new Intent(getActivity(), MapActivity.class);
                    startActivity(i);
                }

            }
        });
        drawerList.setAdapter(adapter);

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }


}
