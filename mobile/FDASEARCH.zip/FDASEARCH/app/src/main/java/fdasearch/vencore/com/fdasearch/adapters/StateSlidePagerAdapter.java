package fdasearch.vencore.com.fdasearch.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import java.util.List;

import fdasearch.vencore.com.fdasearch.fragments.ProductSlidePagerFragment;


public class StateSlidePagerAdapter extends FragmentStatePagerAdapter {
    private List<String> theList;


    public StateSlidePagerAdapter(FragmentManager fm, List<String> list) {
        super(fm);

        theList = list;

    }

    @Override
    public Fragment getItem(int position) {
        return ProductSlidePagerFragment.create(position, theList.get(position));
    }

    @Override
    public int getCount() {
        //   Log.i(TAG, "request adapter size is "+ theList.size());
        return theList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return theList.get(position).toUpperCase();
    }

    @Override
    public void destroyItem(View collection, int position, Object o) {
        View view = (View) o;
        ((ViewPager) collection).removeView(view);
        view = null;
    }

}
