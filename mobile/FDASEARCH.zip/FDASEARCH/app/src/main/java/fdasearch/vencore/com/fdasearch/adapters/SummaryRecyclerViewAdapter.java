package fdasearch.vencore.com.fdasearch.adapters;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.BreakIterator;
import java.util.List;

import fdasearch.vencore.com.fdasearch.Product;
import fdasearch.vencore.com.fdasearch.R;


public class SummaryRecyclerViewAdapter extends RecyclerView.Adapter<SummaryRecyclerViewAdapter.ViewHolder> {


    OnItemClickListener mItemClickListener;
    private Context mContext;
    private List<Product> theList;


    public SummaryRecyclerViewAdapter(Context c, List<Product> addr) {

        super();
        mContext = c;
        theList = addr;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,
                                         int viewType) {
        // create a new view
        View itemLayoutView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.prod_list_item, parent, false);

        // create ViewHolder

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);
        return viewHolder;
    }

    // Return the size of your itemsData (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return theList.size();
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        // - get data from your itemsData at this position
        // - replace the contents of the view with that itemsData
        // StateListAnimator sla = AnimatorInflater.loadStateListAnimator(mContext, R.anim.view_pressed);
        //holder.setStateListAnimator(sla);
        final ViewHolder hold = holder;
        holder.type.setText(theList.get(position).getEvent().getProduct_type());
        holder.recall.setText(theList.get(position).getRecall_number());
        holder.description.setText(truncateAfteWords(25, theList.get(position).getProduct_description()));
        holder.reason.setText(truncateAfteWords(25, theList.get(position).getReason_for_recall()));
    }

    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    private String truncateAfteWords(int n, String str) {


        BreakIterator bi = BreakIterator.getWordInstance();
        bi.setText(str);

        if (str.length() > n) {
            int first_after = bi.following(n);
            // to truncate:
            str = str.substring(0, first_after);

            return str + " ...";
        } else return str;
    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView type;
        TextView recall;
        TextView reason;
        TextView description;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            type = (TextView) itemLayoutView.findViewById(R.id.product_type);
            recall = (TextView) itemLayoutView.findViewById(R.id.product_recall_number);
            reason = (TextView) itemLayoutView.findViewById(R.id.product_recall_reason);
            description = (TextView) itemLayoutView.findViewById(R.id.product_description);
            itemLayoutView.setOnClickListener(this);
            // itemLayoutView.setStateListAnimator(sla);
        }

        @Override
        public void onClick(View v) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }


}

 
