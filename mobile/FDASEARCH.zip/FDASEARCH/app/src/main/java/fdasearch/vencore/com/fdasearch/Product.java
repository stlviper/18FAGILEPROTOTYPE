package fdasearch.vencore.com.fdasearch;

/**
 * Created by komi on 6/23/15.
 */
public class Product {

    private String genericName;

    private String recall_number;
    private String recall_initiation_date;
    private String product_description;
    private String code_info;
    private String recalling_firm;
    private String state;
    private String city;
    private String country;
    private String distribution_pattern;
    private String reason_for_recall;
    private String classification;
    private String product_quantity;
    private Event event_details;


    public Product() {

    }

    public String getGenericName() {
        return genericName;
    }

    public void setGenericName(String genericName) {
        this.genericName = genericName;
    }

    public Event getEvent() {
        return event_details;
    }

    public void setEvent(Event event) {
        this.event_details = event;
    }

    public String getProduct_quantity() {
        return product_quantity;
    }

    public void setProduct_quantity(String product_quantity) {
        this.product_quantity = product_quantity;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getReason_for_recall() {
        return reason_for_recall;
    }

    public void setReason_for_recall(String reason_for_recall) {
        this.reason_for_recall = reason_for_recall;
    }

    public String getDistribution_pattern() {
        return distribution_pattern;
    }

    public void setDistribution_pattern(String distribution_pattern) {
        this.distribution_pattern = distribution_pattern;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRecalling_firm() {
        return recalling_firm;
    }

    public void setRecalling_firm(String recalling_firm) {
        this.recalling_firm = recalling_firm;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public String getRecall_initiation_date() {
        return recall_initiation_date;
    }

    public void setRecall_initiation_date(String recall_initiation_date) {
        this.recall_initiation_date = recall_initiation_date;
    }

    public String getRecall_number() {
        return recall_number;
    }

    public void setRecall_number(String recall_number) {
        this.recall_number = recall_number;
    }

    public String getCode_info() {
        return code_info;
    }

    public void setCode_info(String code_info) {
        this.code_info = code_info;
    }

    @Override
    public String toString() {
        return "Product{" +
                "genericName='" + genericName + '\'' +
                ", recall_number='" + recall_number + '\'' +
                ", recall_initiation_date='" + recall_initiation_date + '\'' +
                ", product_description='" + product_description + '\'' +
                ", code_info='" + code_info + '\'' +
                ", recalling_firm='" + recalling_firm + '\'' +
                ", state='" + state + '\'' +
                ", city='" + city + '\'' +
                ", country='" + country + '\'' +
                ", distribution_pattern='" + distribution_pattern + '\'' +
                ", reason_for_recall='" + reason_for_recall + '\'' +
                ", classification='" + classification + '\'' +
                ", product_quantity='" + product_quantity + '\'' +
                ", event=" + event_details +
                '}';
    }
}
