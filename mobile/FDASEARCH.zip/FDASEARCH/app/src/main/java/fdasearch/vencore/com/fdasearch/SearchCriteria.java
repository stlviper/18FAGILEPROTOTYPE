package fdasearch.vencore.com.fdasearch;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by komi on 6/23/15.
 */
public class SearchCriteria {

    List<String> productTypes;
    List<String> statesSelected;
    String startDate;
    String endDate;
    String searchKey;

    public SearchCriteria(List<String> productType, List<String> statesSlected) {
        this.productTypes = productType;
        this.statesSelected = statesSlected;
    }

    public SearchCriteria() {
        this.productTypes = new ArrayList<String>();
        this.statesSelected = new ArrayList<String>();
        startDate = null;
        endDate = null;
    }

    public List<String> getStatesSlected() {
        return statesSelected;
    }

    public void setStatesSlected(List<String> statesSlected) {
        this.statesSelected = statesSlected;
    }

    public String getSearchKey() {
        return searchKey;
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }

    public void resetStates() {
        statesSelected.clear();
    }

    public void resetProducts() {
        productTypes.clear();
    }

    public List<String> getProductType() {

        return productTypes;
    }

    public void setProductType(List<String> productType) {
        this.productTypes = productType;
    }

    public void addStated(String s) {
        statesSelected.add(s);
    }

    public void addProduct(String prod) {
        productTypes.add(prod);
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public boolean containProduct(String prod) {

        return productTypes.contains(prod);
    }

    public void clearStates() {
        statesSelected.clear();
    }

    public void clearProducts() {
        productTypes.clear();
    }
}
