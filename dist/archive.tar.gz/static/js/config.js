/**
 * Enter the host ip address and port number
 */
var global_constants = {
	"host_ip_address":"localhost", 
	"host_port_number":"80",
    "build_number":"<<JENKINS_BUILD_NUMBER>>",
    "build_date_time":"<<JENKINS_BUILD_TIME>>"
};

